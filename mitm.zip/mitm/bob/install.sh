#!/bin/bash

# this installer is used for bob

echo "Installing bob"

ILOG="/var/log/labinstall.log"

DEBUG=0
KEEPLOG=1

# set up pathnames
export LAB="bob" # name of this lab
export SOURCE="ExerciseCommon_UCLA" # common files

export BASE="/tmp" # source root
export THISLAB="$BASE/$LAB" # lab directory
export DOWNLOADS="$THISLAB/$SOURCE"

# support software
export INSTALL_UCLA="$DOWNLOADS/scripts"

# load the helper functions
export FUNCTIONS="$INSTALL_UCLA/functions"
source $FUNCTIONS
echo "Loaded helper functions"
echo $FUNCTIONS

# lock out incoming users during customization
if [ $DEBUG -eq 0 ] # do this only if "for reals"
then
	NoLogin
fi

# cd into the lab directory
pushd $THISLAB

sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install apache2 elinks links wget netcat-traditional nmap curl net-tools -y &>> $ILOG

# turn off mod_deflate since it makes ettercap's job tougher
sudo a2dismod -f deflate
sudo /etc/init.d/apache2 restart &>> $ILOG

echo "Installing/starting bob specific software..."

echo "Copying scripts..." &>> $ILOG

DEBIAN_FRONTEND=noninteractive apt-get install -y apache2 libcgi-pm-perl elinks links wget netcat-traditional nmap curl psmisc
cp $THISLAB/scripts/apache2.conf /etc/apache2/apache2.conf
a2enmod cgi
service apache2 restart

# copy and start the movie reader scripts
pushd /usr/local/bin
for i in a2start.sh a1start.sh; do
	killall $i 2>/dev/null
	cp $THISLAB/scripts/$i /usr/local/bin/
	sudo chmod 755 /usr/local/bin/$i
	# start the scripts
	./$i &> /dev/null &
done
popd

# install telnet perl libs
DEBIAN_FRONTEND=noninteractive apt-get install libnet-telnet-perl -y &>> $ILOG

# install telnet scripts
killall telstart.sh 2>/dev/null
killall telnet.pl 2>/dev/null
cp $THISLAB/scripts/telnet.pl /usr/local/bin/
sudo chmod 755 /usr/local/bin/telnet.pl
cp $THISLAB/scripts/telstart.sh /usr/local/bin/
sudo chmod 755 /usr/local/bin/telstart.sh

# start a few telnet scripts
pushd /usr/local/bin
for i in `seq 1 5`; do
	./telstart.sh &> /dev/null &
done
popd

echo "Adding users..." &>> $ILOG
useradd jimbo  &>> $ILOG
echo "jimbo:goofy76" | chpasswd  &>> $ILOG
useradd jambo &>> $ILOG
echo "jambo:minnie77" | chpasswd &>> $ILOG
useradd jumbo &>> $ILOG
echo "jumbo:donald78" | chpasswd &>> $ILOG

# install stock ticker CGI script
mkdir /usr/lib/cgi-bin
chmod 755 /usr/lib/cgi-bin
cp $THISLAB/scripts/stock.* /usr/lib/cgi-bin/
sudo chown www-data:www-data /usr/lib/cgi-bin/stock.*
sudo chmod 755 /usr/lib/cgi-bin/stock.*
cp $THISLAB/htdocs/bob-index.html /var/www/html/index.html

echo "Success! Creating success stamp." &>> $ILOG

CreateStamp

echo ">>> Configuration complete." &>> $ILOG

YesLogin

# unmount source files
if [ $DEBUG -eq 0 ] # do this only if "for reals"
then
	rm -rf /tmp/bob/*
fi

if [ $KEEPLOG -eq 0 ]
then
	rm $ILOG
fi